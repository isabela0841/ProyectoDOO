import logo from './logo.svg';
import './App.css';
import Component from './component';

function App() {
  return (
    <div className="App">
      <Component />
    </div>
  );
}

export default App;
