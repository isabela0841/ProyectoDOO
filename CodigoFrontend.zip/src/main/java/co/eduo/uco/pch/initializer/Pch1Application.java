package co.eduo.uco.pch.initializer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pch1Application {

	public static void main(String[] args) {
		SpringApplication.run(Pch1Application.class, args);
	}

}
